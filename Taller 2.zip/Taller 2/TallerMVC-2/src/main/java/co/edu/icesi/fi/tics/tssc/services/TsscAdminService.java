package co.edu.icesi.fi.tics.tssc.services;

import co.edu.icesi.fi.tics.tssc.modelo.TsscAdmin;

public interface TsscAdminService {

	public TsscAdmin saveAdmin (TsscAdmin name);
}
