package co.edu.icesi.fi.tics.tssc.exceptions;

public class StoryNotExistException extends Exception {
	
	public StoryNotExistException() {
		super("No existe la historia");
	}

}
