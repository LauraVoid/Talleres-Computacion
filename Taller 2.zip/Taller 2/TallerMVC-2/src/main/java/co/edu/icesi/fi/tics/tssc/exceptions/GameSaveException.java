package co.edu.icesi.fi.tics.tssc.exceptions;

public class GameSaveException extends Exception{
	
	public GameSaveException() {
		super("No se puede crear un juego");
	}

}
