package co.edu.icesi.fi.tics.tssc.exceptions;

public class StorySaveException extends Exception {
	
	public StorySaveException() {
		super("No es posible guardar el story");
	}

}
