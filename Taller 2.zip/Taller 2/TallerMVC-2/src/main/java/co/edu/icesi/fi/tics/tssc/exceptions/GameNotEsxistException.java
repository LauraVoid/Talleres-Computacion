package co.edu.icesi.fi.tics.tssc.exceptions;

public class GameNotEsxistException extends Exception{
	
	public GameNotEsxistException() {
		super("Game no existe");
	}

}
