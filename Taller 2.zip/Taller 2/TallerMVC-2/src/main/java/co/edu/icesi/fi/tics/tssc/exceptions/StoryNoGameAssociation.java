package co.edu.icesi.fi.tics.tssc.exceptions;

public class StoryNoGameAssociation extends Exception{

}
